'use strict';

const slider = document.querySelector('.testimonials');
const sliderItems = document.querySelectorAll('.testimonial-item');
const sliderArrow = document.querySelector('.testimonial-arrow');
const sliderCount = document.querySelector('.slider__count');
const sliderDots = document.querySelector('.slider__dots');
const sliderDotsImages = document.querySelector('.slider__image-dots');

let currentItem = 0;


function fnInit() {
    sliderInit();
}

fnInit();


// ================ Slider init =============
function sliderInit() {
    function setStyleIntoSlideItem() {
        sliderItems.forEach((item, index) => {
            item.style.transform = `translateX(${(index - currentItem) * 100}%)`
        });
    } 
    setStyleIntoSlideItem();
    activeAuthor();
    
    
    // Slider  Arrows;
}
sliderArrow.addEventListener('click', (e) => {
    const target = e.target.closest('.arrow');
    if(target) {
        if(target.classList.contains('left')) {
            currentItem > 0 && (sliderItems.length - 1) > currentItem - 1 ? currentItem-- : currentItem = sliderItems.length - 1; 
            fnInit();
        } else {
            (sliderItems.length) - 1 > currentItem ? currentItem++ : currentItem = 0;
            fnInit();
        }
    }
    
    sliderInit();
    
})


function activeAuthor() {
    let testimonialAuthors = document.querySelectorAll('.testimonial-author');
    testimonialAuthors.forEach((item, index) => {
        item.setAttribute('data-index', index);
        if(index == currentItem) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }

    })
}



let myTimer = setInterval(() => {
    if((sliderItems.length) - 1 > currentItem) {
        currentItem++;
    } else {
        currentItem = 0;
    }
    sliderInit();
}, 2500)


$('.testimonial-author').on('click', function() {
    let dataIndex = $(this).attr('data-index');
    $(this).addClass('active').siblings().removeClass('active');

    currentItem = dataIndex;
    sliderInit();

})

$('.testimonial-content').on('click', function() {
    clearInterval(myTimer);
})