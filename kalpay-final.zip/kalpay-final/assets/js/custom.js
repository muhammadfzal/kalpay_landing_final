$(document).ready(function() {
    "use strict";

    $('body').on('click', function() {
      $('.brand-page .design-two .text .form .dropdown-area .list').removeClass('active')
    })


    $('.brand-slider').slick({
      infinite: true,
      slidesToShow: 4,
      slidesToScroll: 1,
      autoplay: true,
      prevArrow: '<button type="button" class="slick-prev"><i class="fas fa-chevron-left"></i></button>',
      nextArrow: '<button type="button" class="slick-next"><i class="fas fa-chevron-right"></i></button>',
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
          }
        },
        {
          breakpoint: 992,
          settings: {
            slidesToShow: 2,

          }
        },
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 2,
          }
        }
      ]
    });


 
    $('.sliders-sec').slick({
        infinite: true,
        slidesToShow: 5,
        slidesToScroll: 1,
        // autoplay: true,
        // centerMode: true,
        // arrows: false,
        prevArrow: '<button type="button" class="slick-prev"><i class="fas fa-chevron-left"></i></button>',
        nextArrow: '<button type="button" class="slick-next"><i class="fas fa-chevron-right"></i></button>',
        responsive: [
          {
            breakpoint: 1024,
            settings: {
              slidesToShow: 3,
            }
          },
          {
            breakpoint: 992,
            settings: {
              slidesToShow: 4,

            }
          },
          {
            breakpoint: 768,
            settings: {
              slidesToShow: 2,
            }
          }
        ]
      });



   

      $('.faq .faq-content ul li button').on('click', function() {
        $(this).parents('li').toggleClass('active').find('.answer').slideToggle();
      })

      $('.header .header-content .mobile .border-btn').on('click', function() {
        $('.header .header-content .list').slideToggle();
      })


      $('.brand-page .design-two .text .form .dropdown-area').on('click', function(e) {

        let t = e.target.nodeName;

        if(t == 'INPUT' || t == 'I') {
          e.stopPropagation();
          $(this).find('.list').addClass('active');
        }

      })

      $('.brand-page .design-two .text .form .dropdown-area .list ul li a').on('click', function(e) {
        e.preventDefault();
        let v = $(this).text();

        $(this).parents('.dropdown-area').find('input').val(v);
        $('.dropdown-area').find('.list').removeClass('active');
      })



      $('.brand-page .design-two .text .form .history ul li span').on('click', function() {
        let d = $(this).text();
        $(this).parents('.form').find('#search').val(d);
      })

      $('.brand-page .design-two .text .form .history ul li i').on('click', function() {
        $(this).parents('li').hide();
      })


      $('#subscribe').on('submit', function(e) {
        e.preventDefault();

        let subscriberMail = $('#subscriber_email').val();
        let regex = new RegExp('[a-z0-9]+@[a-z]+\.[a-z]{2,3}');

        

        if(subscriberMail == '' || regex.test(subscriberMail) == false) {
          $('#subscriber_email').addClass('is-invalid');
        }

        

       else {
        var form = $(this),
        url = form.attr('action');

    let formInfo = {
            email: subscriberMail,
            for: 'subscribe'
        }

        $.ajax({
          method: 'POST',
          url: url,
          data: formInfo,
          success: function(response) {
              console.log(response);
              $("#subscribe")[0].reset();
              $('.subscriber-status').show();
              $('.subscriber-status').text('Thank you for subscription.');
          },
          error: function() {
              $('.subscriber-status').text('Something wrong. Please try again later.');
          }
      });
       }

      })

      $('#subscriber_email').on('keyup', function() {
        $(this).removeClass('is-invalid');
      })

});